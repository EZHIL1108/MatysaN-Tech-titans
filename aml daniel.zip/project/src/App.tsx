import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import RoutePlanner from './components/RoutePlanner';
import MarineConditions from './components/MarineConditions';
import WeatherData from './components/WeatherData';
import HistoricalData from './components/HistoricalData';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'route-planner':
        return <RoutePlanner />;
      case 'conditions':
        return <MarineConditions />;
      case 'weather':
        return <WeatherData />;
      case 'history':
        return <HistoricalData />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="pb-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;