import React, { useState } from 'react';
import { Navigation, MapPin, Clock, Fuel, Shield, Target, Route, Play } from 'lucide-react';

const RoutePlanner: React.FC = () => {
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  
  const suggestedRoutes = [
    {
      id: 'route-1',
      name: 'Northern Coastal Route',
      distance: '45 km',
      duration: '3h 20m',
      fuelCost: '$180',
      safetyScore: 95,
      expectedCatch: 'High',
      zones: ['North Bay', 'Coastal Shelf', 'Rocky Outcrops'],
      sustainabilityScore: 88
    },
    {
      id: 'route-2',
      name: 'Eastern Deep Water Route',
      distance: '62 km',
      duration: '4h 45m',
      fuelCost: '$245',
      safetyScore: 78,
      expectedCatch: 'Very High',
      zones: ['Eastern Banks', 'Deep Channel', 'Offshore Waters'],
      sustainabilityScore: 92
    },
    {
      id: 'route-3',
      name: 'Western Mixed Zone Route',
      distance: '38 km',
      duration: '2h 50m',
      fuelCost: '$155',
      safetyScore: 92,
      expectedCatch: 'Medium',
      zones: ['Western Shallows', 'Mid-Water', 'Reef Areas'],
      sustainabilityScore: 85
    }
  ];

  const routeOptimizationFactors = [
    { factor: 'Weather Conditions', weight: 25, current: 'Favorable' },
    { factor: 'Historical Catch Data', weight: 30, current: 'Good' },
    { factor: 'Fuel Efficiency', weight: 20, current: 'Optimal' },
    { factor: 'Safety Assessment', weight: 15, current: 'High' },
    { factor: 'Sustainability Index', weight: 10, current: 'Excellent' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">AI Route Optimization</h2>
        <p className="text-gray-600">Intelligent route planning based on real-time conditions and historical data</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Route Suggestions */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200 mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommended Routes</h3>
            
            <div className="space-y-4">
              {suggestedRoutes.map((route) => (
                <div
                  key={route.id}
                  onClick={() => setSelectedRoute(route.id)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                    selectedRoute === route.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Route className="h-5 w-5 text-blue-600" />
                      <h4 className="font-semibold text-gray-900">{route.name}</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Expected Catch:</span>
                      <span className="font-semibold text-green-600">{route.expectedCatch}</span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                    <div className="flex items-center space-x-2">
                      <Navigation className="h-4 w-4 text-gray-500" />
                      <span>{route.distance}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>{route.duration}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Fuel className="h-4 w-4 text-gray-500" />
                      <span>{route.fuelCost}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Shield className="h-4 w-4 text-gray-500" />
                      <span>{route.safetyScore}%</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Target className="h-4 w-4 text-gray-500" />
                      <span className="text-sm text-gray-600">Zones: {route.zones.join(', ')}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <span className="text-sm text-gray-600">Sustainability: {route.sustainabilityScore}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {selectedRoute && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <button className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2">
                  <Play className="h-5 w-5" />
                  <span>Start Navigation</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Optimization Factors */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Route Optimization Factors</h3>
            
            <div className="space-y-4">
              {routeOptimizationFactors.map((factor, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700">{factor.factor}</span>
                    <span className="text-sm text-gray-600">{factor.weight}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${factor.weight * 4}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-600">Current: {factor.current}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Real-time Adjustments</h3>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Route Optimized</p>
                  <p className="text-xs text-gray-600">Fuel savings: 15%</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Weather Updated</p>
                  <p className="text-xs text-gray-600">Conditions improving</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                <div>
                  <p className="text-sm font-medium text-gray-900">Zone Alert</p>
                  <p className="text-xs text-gray-600">High activity detected</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoutePlanner;