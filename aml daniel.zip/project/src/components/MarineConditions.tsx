import React from 'react';
import { Waves, Thermometer, Eye, Wind, Compass, Activity } from 'lucide-react';

const MarineConditions: React.FC = () => {
  const currentConditions = [
    {
      location: 'North Bay',
      temperature: '18°C',
      waveHeight: '1.2m',
      visibility: '8km',
      windSpeed: '12 knots',
      windDirection: 'NE',
      tideLevel: 'High',
      status: 'Excellent'
    },
    {
      location: 'Eastern Waters',
      temperature: '19°C',
      waveHeight: '1.8m',
      visibility: '6km',
      windSpeed: '18 knots',
      windDirection: 'E',
      tideLevel: 'Medium',
      status: 'Good'
    },
    {
      location: 'Western Coastal',
      temperature: '17°C',
      waveHeight: '2.1m',
      visibility: '5km',
      windSpeed: '22 knots',
      windDirection: 'SW',
      tideLevel: 'Low',
      status: 'Moderate'
    }
  ];

  const forecast = [
    { time: '06:00', wave: 1.0, wind: 10, temp: 17, condition: 'Calm' },
    { time: '09:00', wave: 1.2, wind: 12, temp: 18, condition: 'Slight' },
    { time: '12:00', wave: 1.5, wind: 15, temp: 19, condition: 'Moderate' },
    { time: '15:00', wave: 1.8, wind: 18, temp: 20, condition: 'Moderate' },
    { time: '18:00', wave: 1.4, wind: 14, temp: 18, condition: 'Slight' },
    { time: '21:00', wave: 1.0, wind: 11, temp: 17, condition: 'Calm' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Marine Conditions</h2>
        <p className="text-gray-600">Real-time sea conditions and marine weather data</p>
      </div>

      {/* Current Conditions by Zone */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {currentConditions.map((condition, index) => (
          <div key={index} className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">{condition.location}</h3>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                condition.status === 'Excellent' ? 'bg-green-100 text-green-800' :
                condition.status === 'Good' ? 'bg-blue-100 text-blue-800' :
                'bg-yellow-100 text-yellow-800'
              }`}>
                {condition.status}
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Thermometer className="h-5 w-5 text-red-500" />
                <span className="text-sm text-gray-600">Temperature:</span>
                <span className="font-semibold">{condition.temperature}</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <Waves className="h-5 w-5 text-blue-500" />
                <span className="text-sm text-gray-600">Wave Height:</span>
                <span className="font-semibold">{condition.waveHeight}</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <Eye className="h-5 w-5 text-gray-500" />
                <span className="text-sm text-gray-600">Visibility:</span>
                <span className="font-semibold">{condition.visibility}</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <Wind className="h-5 w-5 text-cyan-500" />
                <span className="text-sm text-gray-600">Wind:</span>
                <span className="font-semibold">{condition.windSpeed} {condition.windDirection}</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <Activity className="h-5 w-5 text-purple-500" />
                <span className="text-sm text-gray-600">Tide Level:</span>
                <span className="font-semibold">{condition.tideLevel}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Forecast Chart */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">24-Hour Marine Forecast</h3>
        
        <div className="overflow-x-auto">
          <div className="flex space-x-8 min-w-full">
            {forecast.map((item, index) => (
              <div key={index} className="flex-shrink-0 text-center">
                <div className="mb-2">
                  <span className="text-sm font-medium text-gray-600">{item.time}</span>
                </div>
                
                <div className="bg-gradient-to-b from-blue-100 to-blue-200 rounded-lg p-4 mb-2 w-24">
                  <div className="space-y-2">
                    <div className="flex items-center justify-center">
                      <Waves className="h-4 w-4 text-blue-600 mr-1" />
                      <span className="text-sm font-semibold">{item.wave}m</span>
                    </div>
                    <div className="flex items-center justify-center">
                      <Wind className="h-4 w-4 text-cyan-600 mr-1" />
                      <span className="text-sm font-semibold">{item.wind}kt</span>
                    </div>
                    <div className="flex items-center justify-center">
                      <Thermometer className="h-4 w-4 text-red-600 mr-1" />
                      <span className="text-sm font-semibold">{item.temp}°C</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-xs text-gray-600 font-medium">{item.condition}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Marine Warnings */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Marine Warnings & Advisories</h3>
        
        <div className="space-y-3">
          <div className="flex items-start space-x-3 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="w-2 h-2 rounded-full bg-yellow-500 mt-2"></div>
            <div>
              <p className="font-medium text-gray-900">Small Craft Advisory</p>
              <p className="text-sm text-gray-600">Western zones may experience increased wave activity between 14:00-18:00</p>
              <p className="text-xs text-gray-500 mt-1">Valid until: 20:00 today</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
            <div>
              <p className="font-medium text-gray-900">Visibility Advisory</p>
              <p className="text-sm text-gray-600">Reduced visibility expected in eastern waters due to morning fog</p>
              <p className="text-xs text-gray-500 mt-1">Valid until: 10:00 tomorrow</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
            <div>
              <p className="font-medium text-gray-900">Favorable Conditions</p>
              <p className="text-sm text-gray-600">Excellent fishing conditions expected in northern waters tomorrow morning</p>
              <p className="text-xs text-gray-500 mt-1">Forecast for: 06:00-12:00 tomorrow</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarineConditions;