import React from 'react';
import { TrendingUp, AlertTriangle, Anchor, Thermometer, Wind, Eye } from 'lucide-react';

const Dashboard: React.FC = () => {
  const currentConditions = [
    { label: 'Sea Temperature', value: '18°C', icon: Thermometer, status: 'good' },
    { label: 'Wind Speed', value: '12 knots', icon: Wind, status: 'moderate' },
    { label: 'Visibility', value: '8 km', icon: Eye, status: 'good' },
    { label: 'Wave Height', value: '1.2m', icon: Anchor, status: 'good' },
  ];

  const aiRecommendations = [
    {
      zone: 'North Bay Area',
      confidence: 92,
      expectedCatch: 'High',
      risk: 'Low',
      species: 'Mackerel, Sardines',
      bestTime: '06:00 - 10:00'
    },
    {
      zone: 'Eastern Coastal Waters',
      confidence: 78,
      expectedCatch: 'Medium',
      risk: 'Low',
      species: 'Tuna, Snapper',
      bestTime: '14:00 - 18:00'
    },
    {
      zone: 'Western Deep Waters',
      confidence: 65,
      expectedCatch: 'High',
      risk: 'Medium',
      species: 'Grouper, Amberjack',
      bestTime: '05:00 - 09:00'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Fishing Conditions Overview</h2>
        <p className="text-gray-600">Real-time marine conditions and AI-powered recommendations</p>
      </div>

      {/* Current Conditions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {currentConditions.map((condition, index) => {
          const Icon = condition.icon;
          const statusColor = condition.status === 'good' ? 'green' : condition.status === 'moderate' ? 'yellow' : 'red';
          
          return (
            <div key={index} className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <Icon className={`h-8 w-8 text-${statusColor}-600`} />
                <div className={`w-3 h-3 rounded-full bg-${statusColor}-400`}></div>
              </div>
              <p className="text-sm text-gray-600 mb-1">{condition.label}</p>
              <p className="text-2xl font-bold text-gray-900">{condition.value}</p>
            </div>
          );
        })}
      </div>

      {/* AI Recommendations */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200 mb-8">
        <div className="flex items-center space-x-2 mb-6">
          <TrendingUp className="h-6 w-6 text-blue-600" />
          <h3 className="text-xl font-semibold text-gray-900">AI-Powered Zone Recommendations</h3>
        </div>
        
        <div className="space-y-4">
          {aiRecommendations.map((rec, index) => (
            <div key={index} className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-900">{rec.zone}</h4>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">Confidence:</span>
                  <span className="font-semibold text-blue-600">{rec.confidence}%</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Expected Catch</p>
                  <p className="font-semibold text-gray-900">{rec.expectedCatch}</p>
                </div>
                <div>
                  <p className="text-gray-600">Risk Level</p>
                  <p className="font-semibold text-gray-900">{rec.risk}</p>
                </div>
                <div>
                  <p className="text-gray-600">Target Species</p>
                  <p className="font-semibold text-gray-900">{rec.species}</p>
                </div>
                <div>
                  <p className="text-gray-600">Best Time</p>
                  <p className="font-semibold text-gray-900">{rec.bestTime}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Alerts */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <div className="flex items-center space-x-2 mb-4">
          <AlertTriangle className="h-6 w-6 text-orange-600" />
          <h3 className="text-xl font-semibold text-gray-900">Active Alerts</h3>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
            <div>
              <p className="font-medium text-gray-900">Weather Advisory</p>
              <p className="text-sm text-gray-600">Moderate winds expected in western zones after 16:00</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
            <div>
              <p className="font-medium text-gray-900">Migration Alert</p>
              <p className="text-sm text-gray-600">Tuna school detected moving toward eastern waters</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;