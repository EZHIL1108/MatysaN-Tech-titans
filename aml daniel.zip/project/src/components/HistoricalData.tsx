import React, { useState } from 'react';
import { TrendingUp, Fish, Calendar, MapPin, BarChart3, Target } from 'lucide-react';

const HistoricalData: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('30days');
  
  const catchData = [
    { species: 'Tuna', total: 1250, avgSize: '25kg', bestZone: 'Eastern Waters', trend: 'up' },
    { species: 'Mackerel', total: 2800, avgSize: '1.2kg', bestZone: 'North Bay', trend: 'up' },
    { species: 'Sardines', total: 4200, avgSize: '0.3kg', bestZone: 'Coastal Shelf', trend: 'stable' },
    { species: 'Snapper', total: 850, avgSize: '2.8kg', bestZone: 'Rocky Outcrops', trend: 'down' },
    { species: 'Grouper', total: 420, avgSize: '8.5kg', bestZone: 'Deep Waters', trend: 'up' },
    { species: 'Amberjack', total: 650, avgSize: '12kg', bestZone: 'Offshore Banks', trend: 'stable' }
  ];

  const monthlyTrends = [
    { month: 'Jan', catch: 8200, revenue: 24600, efficiency: 85 },
    { month: 'Feb', catch: 9100, revenue: 27300, efficiency: 88 },
    { month: 'Mar', catch: 11200, revenue: 33600, efficiency: 92 },
    { month: 'Apr', catch: 10800, revenue: 32400, efficiency: 90 },
    { month: 'May', catch: 12500, revenue: 37500, efficiency: 94 },
    { month: 'Jun', catch: 13800, revenue: 41400, efficiency: 96 }
  ];

  const traditionalKnowledge = [
    {
      title: 'Seasonal Migration Patterns',
      description: 'Tuna schools typically move eastward during spring months (March-May)',
      confidence: 92,
      source: 'Local fishing community'
    },
    {
      title: 'Moon Phase Influence',
      description: 'Higher catch rates observed during new moon phases for night fishing',
      confidence: 78,
      source: 'Historical records'
    },
    {
      title: 'Weather Pattern Correlation',
      description: 'Calm conditions after storms often yield better results in shallow waters',
      confidence: 85,
      source: 'Traditional knowledge'
    },
    {
      title: 'Optimal Fishing Times',
      description: 'Dawn and dusk periods show 40% higher success rates across all species',
      confidence: 96,
      source: 'Data analysis'
    }
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'down':
        return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
      default:
        return <BarChart3 className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Historical Fishing Data</h2>
        <p className="text-gray-600">Comprehensive analysis of catch patterns and traditional knowledge</p>
      </div>

      {/* Time Frame Selection */}
      <div className="mb-8">
        <div className="flex space-x-2">
          {['7days', '30days', '90days', '1year'].map((period) => (
            <button
              key={period}
              onClick={() => setSelectedTimeframe(period)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedTimeframe === period
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {period === '7days' ? 'Last 7 Days' : 
               period === '30days' ? 'Last 30 Days' :
               period === '90days' ? 'Last 90 Days' : 'Last Year'}
            </button>
          ))}
        </div>
      </div>

      {/* Catch Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Species Catch Summary</h3>
          
          <div className="space-y-4">
            {catchData.map((species, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Fish className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="font-medium text-gray-900">{species.species}</p>
                    <p className="text-sm text-gray-600">{species.total} kg total</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Avg. Size</p>
                    <p className="font-semibold text-gray-900">{species.avgSize}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Best Zone</p>
                    <p className="font-semibold text-gray-900">{species.bestZone}</p>
                  </div>
                  {getTrendIcon(species.trend)}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Performance Trends</h3>
          
          <div className="space-y-4">
            {monthlyTrends.map((month, index) => (
              <div key={index} className="grid grid-cols-4 gap-4 p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">Month</p>
                  <p className="font-semibold text-gray-900">{month.month}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Catch (kg)</p>
                  <p className="font-semibold text-gray-900">{month.catch.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Revenue ($)</p>
                  <p className="font-semibold text-gray-900">{month.revenue.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Efficiency</p>
                  <p className="font-semibold text-green-600">{month.efficiency}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Traditional Knowledge Integration */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Traditional Fishing Knowledge</h3>
        <p className="text-gray-600 mb-6">AI-integrated insights from traditional fishing practices and local expertise</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {traditionalKnowledge.map((knowledge, index) => (
            <div key={index} className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-4 border border-blue-200">
              <div className="flex items-start space-x-3">
                <Target className="h-5 w-5 text-blue-600 mt-1" />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 mb-2">{knowledge.title}</h4>
                  <p className="text-sm text-gray-700 mb-3">{knowledge.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                      <span className="text-xs text-gray-600">{knowledge.source}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-gray-600">Confidence:</span>
                      <span className="text-xs font-semibold text-blue-600">{knowledge.confidence}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HistoricalData;